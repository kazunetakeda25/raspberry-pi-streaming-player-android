package com.local.rpi.streamingplayer

class Player(playerName: String, status: String) {
    var playerName: String? = playerName
    var status: String? = status
}

class TuneInSubCategory(title: String, href: String) {
    var title: String? = title
    var href: String? = href
}

class TuneInSubCategoryItem(image: String, title: String, subImage: String, subtitle: String, href: String) {
    var image: String? = image
    var title: String? = title
    var subImage: String? = subImage
    var subTitle: String? = subtitle
    var href: String? = href
}
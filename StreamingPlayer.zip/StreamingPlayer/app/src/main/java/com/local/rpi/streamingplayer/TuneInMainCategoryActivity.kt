package com.local.rpi.streamingplayer

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_tunein_main_category.*

class TuneInMainCategoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tunein_main_category)
        btnSearch.setOnClickListener {
            loadTuneInSubCategoryActivity("Search")
        }
        btnLocalRadio.setOnClickListener {
            loadTuneInSubCategoryActivity("LocalRadio")
        }
        btnMusic.setOnClickListener {
            loadTuneInSubCategoryActivity("Music")
        }
        btnNews.setOnClickListener {
            loadTuneInSubCategoryActivity("News")
        }
        btnSport.setOnClickListener {
            loadTuneInSubCategoryActivity("Sport")
        }
        btnPodcasts.setOnClickListener {
            loadTuneInSubCategoryActivity("Podcasts")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when {
            item.itemId == R.id.action_main -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                true
            }
            item.itemId == R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun loadTuneInSubCategoryActivity(category: String) {
        var intent = Intent()
        if (category == "Search") {
            intent = Intent(this, TuneInSubCategoryItemActivity::class.java)
            intent.putExtra("href", "http://opml.radiotime.com/Search.ashx?query=${searchInput.text}")
        } else {
            intent = Intent(this, TuneInSubCategoryActivity::class.java)
            intent.putExtra("category", category)
        }
        startActivity(intent)
    }
}
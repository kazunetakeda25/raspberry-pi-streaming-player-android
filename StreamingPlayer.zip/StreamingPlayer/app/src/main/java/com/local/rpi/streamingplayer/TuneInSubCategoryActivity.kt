package com.local.rpi.streamingplayer

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_tunein_sub_category.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser
import org.jsoup.select.Elements
import java.io.IOException
import java.util.*

class TuneInSubCategoryActivity : AppCompatActivity() {

    private val tuneInSubCategoryList = ArrayList<TuneInSubCategory>()
    private var recyclerView: RecyclerView? = null
    private var subCategoryAdapter: TuneInSubCategoryAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tunein_sub_category)
        recyclerView = recycler_view as RecyclerView
        subCategoryAdapter = TuneInSubCategoryAdapter(tuneInSubCategoryList)
        recyclerView!!.setHasFixedSize(true)
        val mLayoutManager = LinearLayoutManager(applicationContext)
        recyclerView!!.layoutManager = mLayoutManager
        recyclerView!!.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))
        recyclerView!!.itemAnimator = DefaultItemAnimator()
        recyclerView!!.adapter = subCategoryAdapter
        recyclerView!!.addOnItemTouchListener(RecyclerTouchListener(applicationContext, recyclerView!!, object : RecyclerTouchListener.ClickListener {
            override fun onLongClick(view: View?, position: Int) : Boolean {
                return true
            }
            override fun onClick(view: View, position: Int) {
                val list = tuneInSubCategoryList[position]
                Toast.makeText(applicationContext, list.title + " is selected!", Toast.LENGTH_SHORT).show()
                launchTuneInCategoryItemActivity(position)
            }
        }))
        showTuneInSubCategoryList()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when {
            item.itemId == R.id.action_main -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                true
            }
            item.itemId == R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun launchTuneInCategoryItemActivity(index: Int) {
        val intent = Intent(this, TuneInSubCategoryItemActivity::class.java)
        intent.putExtra("href", tuneInSubCategoryList[index].href)
        startActivity(intent)
    }

    private fun showTuneInSubCategoryList() {
        Thread(Runnable {
            var guideItemLinks = Elements()
            this@TuneInSubCategoryActivity.run {
                try {
                    var doc = Document("")
                    when {
                        intent.getStringExtra("category") == "LocalRadio" -> doc = Jsoup.connect("http://opml.radiotime.com/Browse.ashx?c=local").get()
                        intent.getStringExtra("category") == "Music" -> doc = Jsoup.connect("http://opml.radiotime.com/Browse.ashx?c=music").get()
                        intent.getStringExtra("category") == "News" -> doc = Jsoup.connect("http://opml.radiotime.com/Browse.ashx?c=talk").get()
                        intent.getStringExtra("category") == "Sport" -> doc = Jsoup.connect("http://opml.radiotime.com/Browse.ashx?c=sports").get()
                        intent.getStringExtra("category") == "Podcasts" -> doc = Jsoup.connect("http://opml.radiotime.com/Browse.ashx?c=podcast").get()
                    }
                    doc = Jsoup.parse(doc.toString(), "", Parser.xmlParser())
                    guideItemLinks = doc.select("outline")
                } catch (e: IOException) {

                }
            }
            this@TuneInSubCategoryActivity.runOnUiThread {
                for (guideItemLink in guideItemLinks) {
                    val tunInSubCategoryItem = TuneInSubCategory(guideItemLink.attr("text"), guideItemLink.attr("URL"))
                    tuneInSubCategoryList.add(tunInSubCategoryItem)
                }
                subCategoryAdapter!!.notifyDataSetChanged()
            }
        }).start()
    }
}
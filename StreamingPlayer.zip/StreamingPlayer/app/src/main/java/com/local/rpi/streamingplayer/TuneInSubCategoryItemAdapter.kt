package com.local.rpi.streamingplayer

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class TuneInSubCategoryItemAdapter(private val tuneInSubCategoryItemList: List<TuneInSubCategoryItem>)
    : RecyclerView.Adapter<TuneInSubCategoryItemAdapter.MyViewHolder>() {

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var image: ImageView = view.findViewById<View>(R.id.image) as ImageView
        var title: TextView = view.findViewById<View>(R.id.title) as TextView
        var subImage: ImageView = view.findViewById<View>(R.id.subImage) as ImageView
        var subTitle: TextView = view.findViewById<View>(R.id.subTitle) as TextView
        var href: String? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.tunein_sub_category_item_list_row, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = tuneInSubCategoryItemList[position]
        Glide.with(holder.itemView.context).load(item.image).into(holder.image)
        holder.title.text = item.title
        Glide.with(holder.itemView.context).load(item.subImage).into(holder.subImage)
        holder.subTitle.text = item.subTitle
        holder.href = item.href
    }

    override fun getItemCount(): Int {
        return tuneInSubCategoryItemList.size
    }
}
package com.local.rpi.streamingplayer

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_tunein_sub_category.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser
import org.jsoup.select.Elements
import java.io.IOException
import java.util.*

class TuneInSubCategoryItemActivity : AppCompatActivity() {

    private val tuneInSubCategoryItemList = ArrayList<TuneInSubCategoryItem>()
    private var recyclerView: RecyclerView? = null
    private var subCategoryItemAdapter: TuneInSubCategoryItemAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tunein_sub_category_item)
        recyclerView = recycler_view as RecyclerView
        subCategoryItemAdapter = TuneInSubCategoryItemAdapter(tuneInSubCategoryItemList)
        recyclerView!!.setHasFixedSize(true)
        val mLayoutManager = LinearLayoutManager(applicationContext)
        recyclerView!!.layoutManager = mLayoutManager
        recyclerView!!.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))
        recyclerView!!.itemAnimator = DefaultItemAnimator()
        recyclerView!!.adapter = subCategoryItemAdapter
        recyclerView!!.addOnItemTouchListener(RecyclerTouchListener(applicationContext, recyclerView!!, object : RecyclerTouchListener.ClickListener {
            override fun onLongClick(view: View?, position: Int) : Boolean {
                return true
            }
            override fun onClick(view: View, position: Int) {
                val list = tuneInSubCategoryItemList[position]
                Toast.makeText(applicationContext, list.title + " is selected!", Toast.LENGTH_SHORT).show()
                //launchPlayerActivity(position)
            }
        }))
        showTuneInSubCategoryList()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when {
            item.itemId == R.id.action_main -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                true
            }
            item.itemId == R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showTuneInSubCategoryList() {
        Thread(Runnable {
            var guideItemLinks = Elements()
            this@TuneInSubCategoryItemActivity.run {
                try {
                    var doc : Document = Jsoup.connect(intent.getStringExtra("href")).get()
                    doc = Jsoup.parse(doc.toString(), "", Parser.xmlParser())
                    guideItemLinks = doc.select("outline")
                } catch (e: IOException) {

                }
            }
            this@TuneInSubCategoryItemActivity.runOnUiThread {
                for (guideItemLink in guideItemLinks) {
                    if (guideItemLink.attr("type") == "audio"
                            || guideItemLink.attr("type") == "link") {
                        val tunInSubCategoryItem = TuneInSubCategoryItem(guideItemLink.attr("image"),
                                guideItemLink.attr("text"),
                                guideItemLink.attr("playing_image"),
                                guideItemLink.attr("subtext"),
                                guideItemLink.attr("URL"))
                        tuneInSubCategoryItemList.add(tunInSubCategoryItem)
                    }
                }
                subCategoryItemAdapter!!.notifyDataSetChanged()
            }
        }).start()
    }
}
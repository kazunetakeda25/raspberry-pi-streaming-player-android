package com.local.rpi.streamingplayer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    private val playerList = ArrayList<Player>()
    private var recyclerView: RecyclerView? = null
    private var pAdapter: PlayerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        recyclerView = recycler_view as RecyclerView
        pAdapter = PlayerAdapter(playerList)
        recyclerView!!.setHasFixedSize(true)
        val mLayoutManager = LinearLayoutManager(applicationContext)
        recyclerView!!.layoutManager = mLayoutManager
        recyclerView!!.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))
        recyclerView!!.itemAnimator = DefaultItemAnimator()
        recyclerView!!.adapter = pAdapter
        recyclerView!!.addOnItemTouchListener(RecyclerTouchListener(applicationContext, recyclerView!!, object : RecyclerTouchListener.ClickListener {
            override fun onLongClick(view: View?, position: Int) : Boolean {
                return true
            }
            override fun onClick(view: View, position: Int) {
                val movie = playerList[position]
                Toast.makeText(applicationContext, movie.playerName + " is selected!", Toast.LENGTH_SHORT).show()
            }
        }))
        findDevices()
        fab.setOnClickListener { view ->
            Snackbar.make(view, "No action yet", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show()
        }
    }

    @SuppressLint("HardwareIds")
    private fun findDevices() {
        var movie = Player("Player1", "Currently playing...")
        playerList.add(movie)
        movie = Player("Player2", "Currently playing...")
        playerList.add(movie)
        movie = Player("Player3", "Currently playing...")
        playerList.add(movie)
        pAdapter!!.notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when {
            item.itemId == R.id.action_main -> {
                true
            }
            item.itemId == R.id.action_settings -> {
//                val intent = Intent(this, SettingsActivity::class.java)
//                startActivity(intent)
                val intent = Intent(this, TuneInMainCategoryActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}